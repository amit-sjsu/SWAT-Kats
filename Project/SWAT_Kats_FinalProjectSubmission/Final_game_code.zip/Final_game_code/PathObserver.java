/**
 * Write a description of class PathObserver here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public interface PathObserver  
{
    // instance variables - replace the example below with your own
    void updateSelect(IEdge path);
    void updateUnSelect(IEdge path);
}

/**
 * Write a description of class TimeObserver here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public interface TimeObserver  
{
    // instance variables - replace the example below with your own
    void submitTimeExpire();
   
}
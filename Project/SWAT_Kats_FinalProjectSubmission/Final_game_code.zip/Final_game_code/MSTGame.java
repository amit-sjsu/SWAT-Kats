import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MSTGame here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MSTGame extends World
{
    //GreenfootSound rain = new GreenfootSound("rain-03.wav");
    /**
     * Constructor for objects of class MSTGame.
     * 
     */
    public MSTGame()
    {    
        
        super(1000, 800, 1);
        
       // rain.playLoop();
    }
    
    public void stopped()
    {
       // rain.pause();
    }
    
    public void started()
    {
       // rain.playLoop();
    }
}

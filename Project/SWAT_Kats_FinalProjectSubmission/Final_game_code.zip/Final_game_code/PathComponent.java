/**
 * Write a description of class PathComponent here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public interface PathComponent  
{
    void selectPath();
    void unSelectPath();
}
